# Python Library for the UE5 Utilities used by Algorithm Products

This package contains general util classes/datatypes used by the Team at Algorithm Products regarding their UE5 Render Farm tool.